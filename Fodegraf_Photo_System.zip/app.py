from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash
import os
from datetime import datetime, timedelta
import threading
import time
from pathlib import Path

app = Flask(__name__)
app.secret_key = 'F0de1234'

# Path configuration
USER_HOME = Path.home()
MY_DOCUMENTS = USER_HOME / 'Documents'
FOTO_SEND = MY_DOCUMENTS / 'Foto_Send'
FOTO_EXPIRED = MY_DOCUMENTS / 'Foto_Expired'

# Create directories if not exists
FOTO_SEND.mkdir(exist_ok=True)
FOTO_EXPIRED.mkdir(exist_ok=True)

download_times = {}

def check_expired_photos():
    while True:
        now = datetime.now()
        expired_ids = []
        
        for photo_id, download_time in download_times.items():
            if now > download_time + timedelta(minutes=5):
                source = FOTO_SEND / f"{photo_id}.jpg"
                destination = FOTO_EXPIRED / f"{photo_id}.jpg"
                
                if source.exists():
                    try:
                        source.rename(destination)
                        expired_ids.append(photo_id)
                    except Exception as e:
                        print(f"Error moving file: {e}")
        
        for photo_id in expired_ids:
            download_times.pop(photo_id, None)
        
        time.sleep(60)

# Start background thread
thread = threading.Thread(target=check_expired_photos, daemon=True)
thread.start()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/gallery', methods=['POST'])
def gallery():
    photo_id = request.form.get('photo_id')
    photo_path = FOTO_SEND / f"{photo_id}.jpg"
    
    if photo_path.exists():
        return render_template('gallery.html', photo_id=photo_id)
    else:
        flash('Foto tidak ditemukan. Silakan coba ID yang lain.', 'error')
        return redirect(url_for('index'))

@app.route('/download/<photo_id>')
def download(photo_id):
    download_times[photo_id] = datetime.now()
    return send_from_directory(str(FOTO_SEND), f"{photo_id}.jpg", as_attachment=True)

@app.route('/check_photo/<photo_id>')
def check_photo(photo_id):
    photo_path = FOTO_SEND / f"{photo_id}.jpg"
    return {'exists': photo_path.exists()}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)