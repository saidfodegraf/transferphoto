document.addEventListener('DOMContentLoaded', function () {
  // Check if on gallery page
  const photoDisplay = document.getElementById('photo-display');

  if (photoDisplay) {
    const photoId = photoDisplay.getAttribute('alt').split(' ')[1];

    // Check if photo exists
    fetch(`/check_photo/${photoId}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.exists) {
          // If photo exists, load it
          photoDisplay.src = photoDisplay.dataset.src;
        } else {
          // If photo doesn't exist, show not found image
          photoDisplay.src =
            "{{ url_for('static', filename='not-found.png') }}";
          photoDisplay.alt = 'Foto tidak ditemukan';

          // Disable download button
          const downloadBtn = document.querySelector('.download-btn');
          if (downloadBtn) {
            downloadBtn.style.opacity = '0.5';
            downloadBtn.style.pointerEvents = 'none';
            downloadBtn.textContent = 'Foto Tidak Tersedia';
          }
        }
      })
      .catch((error) => {
        console.error('Error checking photo:', error);
      });
  }
});
